export interface Agent {
  id: string;
  tipo_de_agente: string;
  nome: string;
  foto_perfil: string;
  prompt_do_agente: string;
  descricao: string;
  criado_em: string;
}

