export interface Upload {
  url: string; 
}