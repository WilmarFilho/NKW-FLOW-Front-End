export interface Subscription {
  id: string; 
  user_id: string;
  plano: string;
  ativo: boolean;
  criado_em: string; 
}